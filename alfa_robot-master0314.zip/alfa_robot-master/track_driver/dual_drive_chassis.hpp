// Copyright (c) 2026, alfa
// All rights reserved.
//
// Proprietary License
//
// Unauthorized copying of this file, via any medium is strictly prohibited.
// The file is considered confidential.

#ifndef ALFA_ROBOT_HARDWARE__DUAL_DRIVE_CHASSIS_HPP_
#define ALFA_ROBOT_HARDWARE__DUAL_DRIVE_CHASSIS_HPP_

#include <cstdint>
#include <optional>
#include <string>

namespace alfa_robot_hardware
{

struct DualDriveHeartbeat
{
  int16_t a_speed_units{0};
  int16_t b_speed_units{0};
  uint16_t a_elec_angle{0};
  uint16_t b_elec_angle{0};
};

struct DualDriveFaults
{
  uint16_t a_fault{0};
  uint16_t b_fault{0};
};

class DualDriveChassis
{
public:
  DualDriveChassis() = default;
  ~DualDriveChassis();

  DualDriveChassis(const DualDriveChassis &) = delete;
  DualDriveChassis & operator=(const DualDriveChassis &) = delete;

  void setInterface(const std::string & can_interface);
  void setMaxVelocityRadPerS(double max_velocity_rad_per_s);
  void setPositionUnitsPerRad(double units_per_rad);

  bool open();
  void close();

  bool available() const;

  void enableMotors();
  void disableMotors();

  /** 驱动轮角速度 (rad/s)，内部乘以减速比后按电机角速度下发 */
  void writeWheelVelocities(double left_wheel_rad_s, double right_wheel_rad_s);
  void writeMotorPositions(double a_pos_rad, double b_pos_rad);

  /** P 控制：根据目标/当前轮角计算速度并调用 writeWheelVelocities */
  void writeWheelAngles(double target_left_rad, double target_right_rad,
                        double current_left_rad, double current_right_rad,
                        double kp = 2.0, double max_wheel_vel = 2.0, double tolerance = 0.02);

  std::optional<DualDriveHeartbeat> drainLatestHeartbeat();

  /** 向控制 ID 发送故障查询 (40 12 21 01 00 00 00 00)，监听 0x05800001 解析 60 12 21 01 DATA... */
  std::optional<DualDriveFaults> queryFaults();

private:
  // 手册：扩展帧 ID 定义，发送时须带 CAN_EFF_FLAG
  static constexpr uint32_t kControlCanId = 0x06000001u;      // 控制 ID (扩展帧)
  static constexpr uint32_t kHeartbeatCanId = 0x07000001u;    // 心跳回复 ID (扩展帧)
  static constexpr uint32_t kQueryResponseCanId = 0x05800001u;   // 故障等查询反馈 ID (扩展帧)
  static constexpr uint32_t kQueryResponseIdBase = 0x05800000u;  // 查询返回 ID 基址

  // 底盘减速机减速比：轮角速度 * kGearRatio = 电机角速度
  static constexpr double kGearRatio = 50.0;

  // 手册 Index：速度 0x2000，使能 0x200D，失能 0x200C；SubIndex 0x01=A 0x02=B
  static constexpr uint16_t kIdxSpeedCmd = 0x2000;          // 速度控制
  static constexpr uint16_t kIdxDisable = 0x200C;           // 失能
  static constexpr uint16_t kIdxEnableKeepalive = 0x200D;   // 使能/保活

  static std::optional<int> openCanSocketNonBlocking(const std::string & ifname);
  static void closeCanSocket(int & fd);
  static bool sendEffFrame(int fd, uint32_t can_id_29, const uint8_t * data, uint8_t dlc);
  static bool recvFrameNonBlocking(int fd, uint32_t & can_id_out, uint8_t * data_out, uint8_t & dlc_out);

  static void packSdoWriteU32(uint8_t * out8, uint16_t index, uint8_t subindex, uint32_t value);
  static inline uint16_t be16(uint8_t hi, uint8_t lo);
  static inline int16_t be16s(uint8_t hi, uint8_t lo);
  static int32_t clampI32(int64_t v, int32_t lo, int32_t hi);

  void refreshKeepaliveIfNeeded();
  int32_t radPerSecToUnits(double v_rad_s) const;
  int32_t radToPosUnits(double pos_rad) const;

  std::string can_interface_{"can2"};
  double max_velocity_rad_per_s_{12.56};
  double position_units_per_rad_{1.0};

  int fd_{-1};
  bool available_{false};

  int64_t last_keepalive_ms_{0};
  int64_t last_cmd_time_ms_{0};
};

}  // namespace alfa_robot_hardware

#endif  // ALFA_ROBOT_HARDWARE__DUAL_DRIVE_CHASSIS_HPP_

