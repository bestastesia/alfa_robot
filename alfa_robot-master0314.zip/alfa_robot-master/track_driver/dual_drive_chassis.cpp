// Copyright (c) 2026, alfa
// All rights reserved.
//
// Proprietary License
//
// Unauthorized copying of this file, via any medium is strictly prohibited.
// The file is considered confidential.

#include "dual_drive_chassis.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <iostream>
#include <limits>
#include <thread>

#include <cerrno>
#include <fcntl.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

namespace alfa_robot_hardware
{
namespace
{
inline int64_t nowMs()
{
  return std::chrono::duration_cast<std::chrono::milliseconds>(
           std::chrono::steady_clock::now().time_since_epoch())
    .count();
}
}  // namespace

DualDriveChassis::~DualDriveChassis()
{
  close();
}

void DualDriveChassis::setInterface(const std::string & can_interface)
{
  can_interface_ = can_interface;
}

void DualDriveChassis::setMaxVelocityRadPerS(double max_velocity_rad_per_s)
{
  if (std::isfinite(max_velocity_rad_per_s) && max_velocity_rad_per_s > 1e-6) {
    max_velocity_rad_per_s_ = max_velocity_rad_per_s;
  }
}

void DualDriveChassis::setPositionUnitsPerRad(double units_per_rad)
{
  if (std::isfinite(units_per_rad) && units_per_rad > 0.0) {
    position_units_per_rad_ = units_per_rad;
  }
}

bool DualDriveChassis::open()
{
  close();
  auto fd_opt = openCanSocketNonBlocking(can_interface_);
  if (!fd_opt.has_value()) {
    available_ = false;
    return false;
  }
  fd_ = fd_opt.value();
  available_ = true;
  last_keepalive_ms_ = nowMs();
  last_cmd_time_ms_ = nowMs();
  return true;
}

void DualDriveChassis::close()
{
  disableMotors();
  closeCanSocket(fd_);
  available_ = false;
}

bool DualDriveChassis::available() const
{
  return available_ && fd_ >= 0;
}

// 手册：使能前先发速度 0 (Index 0x2000) 复位状态机，再发使能 0x200D
void DualDriveChassis::enableMotors()
{
  if (!available()) { return; }
  uint8_t frame[8];
  // 先发 A/B 速度 0，确保状态机复位
  packSdoWriteU32(frame, kIdxSpeedCmd, 0x01u, 0u);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  packSdoWriteU32(frame, kIdxSpeedCmd, 0x02u, 0u);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  // 再发使能
  packSdoWriteU32(frame, kIdxEnableKeepalive, 0x01u, 0u);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  packSdoWriteU32(frame, kIdxEnableKeepalive, 0x02u, 0u);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  last_keepalive_ms_ = nowMs();
}

// 手册：失能 Index 0x200C，电机 A SubIndex 0x01，电机 B SubIndex 0x02
void DualDriveChassis::disableMotors()
{
  if (!available()) { return; }
  uint8_t frame[8];
  packSdoWriteU32(frame, kIdxDisable, 0x01u, 0x00000000u);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  packSdoWriteU32(frame, kIdxDisable, 0x02u, 0x00000000u);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
}

// 手册：速度控制 Index 0x2000；输入为驱动轮角速度 rad/s，乘以减速比后转为电机角速度再发 CAN
void DualDriveChassis::writeWheelVelocities(double left_wheel_rad_s, double right_wheel_rad_s)
{
  if (!available()) { return; }
  last_cmd_time_ms_ = nowMs();

  const double left_motor_rad_s = left_wheel_rad_s * kGearRatio;
  const double right_motor_rad_s = right_wheel_rad_s * kGearRatio;
  const int32_t left_units = radPerSecToUnits(left_motor_rad_s);
  const int32_t right_units = radPerSecToUnits(right_motor_rad_s);

  uint8_t frame[8];
  packSdoWriteU32(frame, kIdxSpeedCmd, 0x01u, static_cast<uint32_t>(left_units));
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  packSdoWriteU32(frame, kIdxSpeedCmd, 0x02u, static_cast<uint32_t>(right_units));
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);

  refreshKeepaliveIfNeeded();
}

void DualDriveChassis::writeWheelAngles(double target_left_rad, double target_right_rad,
  double current_left_rad, double current_right_rad,
  double kp, double max_wheel_vel, double tolerance)
{
  if (!available()) { return; }

  double err_l = target_left_rad - current_left_rad;
  double err_r = target_right_rad - current_right_rad;

  double v_cmd_l = (std::abs(err_l) < tolerance) ? 0.0 : (kp * err_l);
  double v_cmd_r = (std::abs(err_r) < tolerance) ? 0.0 : (kp * err_r);

  v_cmd_l = std::clamp(v_cmd_l, -max_wheel_vel, max_wheel_vel);
  v_cmd_r = std::clamp(v_cmd_r, -max_wheel_vel, max_wheel_vel);

  writeWheelVelocities(v_cmd_l, v_cmd_r);
}

void DualDriveChassis::writeMotorPositions(double a_pos_rad, double b_pos_rad)
{
  if (!available()) { return; }

  const int32_t a_units = radToPosUnits(a_pos_rad);
  const int32_t b_units = radToPosUnits(b_pos_rad);

  uint8_t frame[8];
  packSdoWriteU32(frame, 0x2002, 0x01u, static_cast<uint32_t>(a_units));
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  packSdoWriteU32(frame, 0x2002, 0x02u, static_cast<uint32_t>(b_units));
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);

  refreshKeepaliveIfNeeded();
}

std::optional<DualDriveHeartbeat> DualDriveChassis::drainLatestHeartbeat()
{
  if (!available()) { return std::nullopt; }

  DualDriveHeartbeat latest;
  bool got = false;

  for (int drain = 0; drain < 50; ++drain)
  {
    uint32_t can_id = 0;
    uint8_t data[8] = {0};
    uint8_t dlc = 0;
    if (!recvFrameNonBlocking(fd_, can_id, data, dlc)) { break; }

    // 手册：心跳回复 ID 0x07000001，扩展帧
    const bool is_eff = (can_id & CAN_EFF_FLAG) != 0;
    const uint32_t id29 = can_id & CAN_EFF_MASK;
    if (!is_eff) { continue; }
    if (id29 != kHeartbeatCanId) { continue; }
    if (dlc < 8) { continue; }

    // 手册：心跳 0x07000001，8 字节 = A路转速(16bit) + B路转速(16bit) + A路电角度(16bit) + B路电角度(16bit)，大端
    latest.a_speed_units = be16s(data[0], data[1]);
    latest.b_speed_units = be16s(data[2], data[3]);
    latest.a_elec_angle = be16(data[4], data[5]);
    latest.b_elec_angle = be16(data[6], data[7]);
    got = true;
  }

  if (!got) { return std::nullopt; }
  return latest;
}

// 手册：故障查询 发送 40 12 21 01 00 00 00 00，监听 0x05800001 解析 60 12 21 01 DATA_H DATA_L DATB_H DATB_L
std::optional<DualDriveFaults> DualDriveChassis::queryFaults()
{
  if (!available()) { return std::nullopt; }

  const uint8_t sdo_read_frame[8] = {0x40u, 0x12u, 0x21u, 0x01u, 0x00u, 0x00u, 0x00u, 0x00u};
  if (!sendEffFrame(fd_, kControlCanId, sdo_read_frame, 8)) { return std::nullopt; }

  const int64_t deadline_ms = nowMs() + 200;
  while (nowMs() < deadline_ms)
  {
    uint32_t can_id = 0;
    uint8_t data[8] = {0};
    uint8_t dlc = 0;
    if (!recvFrameNonBlocking(fd_, can_id, data, dlc))
    {
      std::this_thread::sleep_for(std::chrono::milliseconds(2));
      continue;
    }
    const bool is_eff = (can_id & CAN_EFF_FLAG) != 0;
    const uint32_t id29 = can_id & CAN_EFF_MASK;
    if (!is_eff || id29 != kQueryResponseCanId) { continue; }
    if (dlc < 8) { continue; }
    if (data[0] != 0x60u || data[1] != 0x12u || data[2] != 0x21u || data[3] != 0x01u) { continue; }

    DualDriveFaults out;
    out.a_fault = be16(data[4], data[5]);
    out.b_fault = be16(data[6], data[7]);
    return out;
  }
  return std::nullopt;
}

// 主循环 50Hz 时每周期都会调用 writeWheelVelocities，本函数仅作备用保活（0.8s 一次）
void DualDriveChassis::refreshKeepaliveIfNeeded()
{
  const int64_t now_ms = nowMs();
  if ((now_ms - last_keepalive_ms_) <= 800) { return; }

  uint8_t frame[8];
  packSdoWriteU32(frame, kIdxEnableKeepalive, 0x01, 0x00000000);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  packSdoWriteU32(frame, kIdxEnableKeepalive, 0x02, 0x00000000);
  (void)sendEffFrame(fd_, kControlCanId, frame, 8);
  last_keepalive_ms_ = now_ms;
}

int32_t DualDriveChassis::radPerSecToUnits(double v_rad_s) const
{
  if (!std::isfinite(v_rad_s)) { return 0; }
  const double denom = std::max(1e-6, max_velocity_rad_per_s_);
  const double ratio = std::clamp(v_rad_s / denom, -1.0, 1.0);
  const int64_t units = llround(ratio * 10000.0);
  return clampI32(units, -10000, 10000);
}

int32_t DualDriveChassis::radToPosUnits(double pos_rad) const
{
  if (!std::isfinite(pos_rad)) { return 0; }
  const double scaled = pos_rad * position_units_per_rad_;
  const int64_t units = llround(scaled);
  return clampI32(units, std::numeric_limits<int32_t>::min(), std::numeric_limits<int32_t>::max());
}

std::optional<int> DualDriveChassis::openCanSocketNonBlocking(const std::string & ifname)
{
  int s = ::socket(PF_CAN, SOCK_RAW, CAN_RAW);
  if (s < 0) { return std::nullopt; }

  int flags = fcntl(s, F_GETFL, 0);
  if (flags >= 0) { (void)fcntl(s, F_SETFL, flags | O_NONBLOCK); }

  struct ifreq ifr;
  std::memset(&ifr, 0, sizeof(ifr));
  std::snprintf(ifr.ifr_name, IFNAMSIZ, "%s", ifname.c_str());
  if (ioctl(s, SIOCGIFINDEX, &ifr) < 0)
  {
    ::close(s);
    return std::nullopt;
  }

  struct sockaddr_can addr;
  std::memset(&addr, 0, sizeof(addr));
  addr.can_family = AF_CAN;
  addr.can_ifindex = ifr.ifr_ifindex;
  if (bind(s, reinterpret_cast<struct sockaddr *>(&addr), sizeof(addr)) < 0)
  {
    ::close(s);
    return std::nullopt;
  }

  return s;
}

void DualDriveChassis::closeCanSocket(int & fd)
{
  if (fd >= 0)
  {
    ::close(fd);
    fd = -1;
  }
}

bool DualDriveChassis::sendEffFrame(int fd, uint32_t can_id_29, const uint8_t * data, uint8_t dlc)
{
  if (fd < 0) { return false; }
  struct can_frame frame;
  std::memset(&frame, 0, sizeof(frame));
  // 手册要求：发送为扩展帧，必须带 CAN_EFF_FLAG
  frame.can_id = (can_id_29 & CAN_EFF_MASK) | CAN_EFF_FLAG;
  frame.can_dlc = dlc;
  if (dlc > 0 && data != nullptr)
  {
    std::memcpy(frame.data, data, std::min<size_t>(dlc, 8));
  }
  const ssize_t n = ::write(fd, &frame, sizeof(frame));
  return n == static_cast<ssize_t>(sizeof(frame));
}

bool DualDriveChassis::recvFrameNonBlocking(
  int fd, uint32_t & can_id_out, uint8_t * data_out, uint8_t & dlc_out)
{
  if (fd < 0) { return false; }
  struct can_frame frame;
  const ssize_t n = ::read(fd, &frame, sizeof(frame));
  if (n < 0)
  {
    if (errno == EAGAIN || errno == EWOULDBLOCK) { return false; }
    return false;
  }
  if (n != static_cast<ssize_t>(sizeof(frame))) { return false; }

  can_id_out = frame.can_id;
  dlc_out = frame.can_dlc;
  if (data_out != nullptr)
  {
    std::memcpy(data_out, frame.data, 8);
  }
  return true;
}

// 手册例1/例3：0x23 + Index(小端) + SubIndex + Data(32bit 大端，内部位移)
// 例1 使能 A: 23 0D 20 01 00 00 00 00  例3 速度 10%: 23 00 20 01 00 00 03 E8
void DualDriveChassis::packSdoWriteU32(uint8_t * out8, uint16_t index, uint8_t subindex, uint32_t value)
{
  out8[0] = 0x23u;                                     // SDO 写
  out8[1] = static_cast<uint8_t>(index & 0xFFu);       // Index 小端低字节
  out8[2] = static_cast<uint8_t>((index >> 8) & 0xFFu);  // Index 小端高字节
  out8[3] = subindex;                                  // SubIndex
  out8[4] = static_cast<uint8_t>((value >> 24) & 0xFFu);
  out8[5] = static_cast<uint8_t>((value >> 16) & 0xFFu);
  out8[6] = static_cast<uint8_t>((value >> 8) & 0xFFu);
  out8[7] = static_cast<uint8_t>(value & 0xFFu);
}

uint16_t DualDriveChassis::be16(uint8_t hi, uint8_t lo)
{
  return static_cast<uint16_t>((static_cast<uint16_t>(hi) << 8) | static_cast<uint16_t>(lo));
}

int16_t DualDriveChassis::be16s(uint8_t hi, uint8_t lo)
{
  return static_cast<int16_t>(be16(hi, lo));
}

int32_t DualDriveChassis::clampI32(int64_t v, int32_t lo, int32_t hi)
{
  if (v < lo) { return lo; }
  if (v > hi) { return hi; }
  return static_cast<int32_t>(v);
}

}  // namespace alfa_robot_hardware

